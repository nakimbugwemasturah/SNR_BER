<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dataset extends CI_Controller{

    public function __contruct(){
        parent::__construct();
    }

    public function index(){
        $this->load->model("Dataset_model");

        $data = []; $data2=[]; $data3=[];
        $response['success'] = FALSE;
        $response['message'] = "Dataset couldn't be generated.";
        $y=1; $frequency_total=0;
        for ($i=0; $i < 50 ; $i++) { 
            // $modulation='QPSK';
            // $modulation_level = (2*($y-1))+$i;

            // $modulation='16QAM';
            // $modulation_level = -4*($y-1) + $i;

            $modulation='64QAM';
            $modulation_level = -6*($y-1) + $i;

            $modulation_change =  pow($y,$modulation_level);
            $range_probabilities = $y*$modulation_change*$y;
            $modulation_condition = 'Input';
            $data[] =array(
                'modulation' => $modulation,
                'modulation_level' => (is_finite($modulation_level) )?$modulation_level:0,
                'modulation_change' => (is_finite($modulation_change) )?$modulation_change:0,
                'range_probabilities' => (is_finite($range_probabilities) )?$range_probabilities:0,
                'modulation_condition' => $modulation_condition
            );

            $signal_strength_fn=($modulation_change*$y)  + $i;
            $time_iteration = $y;
            $frequency =  2*$time_iteration;
            $frequency_total = 2450; //for the 50 iterations
            $ber = $signal_strength_fn/$frequency_total;
            $error_reduction = -2*$frequency;
            $procedure = $signal_strength_fn/$modulation_level;
            
            $data2[] =array(
                'signal_strength' => (is_finite($signal_strength_fn) )?$signal_strength_fn:0,
                'time_iteration' => (is_finite($time_iteration) )?$time_iteration:0,
                'ber' => (is_finite($ber))?$ber:0,
                'frequency' => (is_finite($frequency) )?$frequency:0,
                'error_reduction' => (is_finite($error_reduction) )?$error_reduction:0,
                'procedure' => (is_finite($procedure))?$procedure:0
            );

            $signal_strength =$signal_strength_fn-$i;
            $throughout= $y/(2+$i);
            $likelihood =  $signal_strength * $frequency;
            $procedure = 2*($throughout *log($likelihood) );
            $performance = $ber/$signal_strength;

            $data3[] =array(
                'signal_strength' => (is_finite($signal_strength))?$signal_strength:0,
                'throughout' => (is_finite($throughout))?$throughout:0,
                'likelihood' => (is_finite($likelihood))?$likelihood:0,
                'procedure' => (is_finite($procedure))?$procedure:0,
                'performance' => (is_finite($performance))?$performance:0
            );
            
            $y++;
        }
        if (!empty($data)) {
            $this->Dataset_model->set($data);
            $this->Dataset_model->set2($data2);
            $this->Dataset_model->set3($data3);

            $response['success'] = TRUE;
            $response['message'] = "Dataset successfully generated.";
        }
        echo json_encode($response); 
    }


}

?>