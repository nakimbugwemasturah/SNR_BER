<?php

/**
 * Description of Dataset1_model
 *
 */
class Dataset_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function set($sent_data){
        return $this->db->insert_batch('dataset_1', $sent_data);
    }

    public function set2($sent_data){
        return $this->db->insert_batch('dataset_2', $sent_data);
    }
    
    public function set3($sent_data){
        return $this->db->insert_batch('dataset_3', $sent_data);
    }

}
